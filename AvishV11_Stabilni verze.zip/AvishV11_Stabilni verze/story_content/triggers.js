function ExecuteScript(strId)
{
  switch (strId)
  {
      case "633zWoJ4Q6K":
        Script1();
        break;
      case "5stZJ2fslL0":
        Script2();
        break;
      case "6aiYoNV2MT3":
        Script3();
        break;
      case "6gCNDRjDWxK":
        Script4();
        break;
      case "6IAuClGhjva":
        Script5();
        break;
      case "6kIKoDbV4nz":
        Script6();
        break;
      case "60UCpLSQ0JI":
        Script7();
        break;
      case "677soKvy2pX":
        Script8();
        break;
      case "6R4rIkcoMzD":
        Script9();
        break;
      case "5lfUmltQKAL":
        Script10();
        break;
      case "5k7Ma4nG6OL":
        Script11();
        break;
      case "6KNPCi6fLBW":
        Script12();
        break;
      case "5XcXMqperN1":
        Script13();
        break;
      case "643R0Uy6Hbt":
        Script14();
        break;
      case "6UcCzPUhIZt":
        Script15();
        break;
      case "6LgbUzuTCJX":
        Script16();
        break;
      case "6NBKkAHWXxC":
        Script17();
        break;
      case "66k8mqsU9TY":
        Script18();
        break;
      case "5u3LtT0SoTi":
        Script19();
        break;
      case "68MwmLg1pCF":
        Script20();
        break;
      case "68Or5tktGof":
        Script21();
        break;
      case "6hmwRRZ3XaN":
        Script22();
        break;
      case "6SbBR77Un07":
        Script23();
        break;
      case "67Xcj8fD4h4":
        Script24();
        break;
      case "63cFYA5Ichh":
        Script25();
        break;
      case "6NjRKUi1bI8":
        Script26();
        break;
      case "5jb1w3DIeFW":
        Script27();
        break;
      case "5wMFANnUrQM":
        Script28();
        break;
      case "6jak78rNv9l":
        Script29();
        break;
      case "60WbGWHSYl6":
        Script30();
        break;
      case "6Hm3qL4yLRV":
        Script31();
        break;
      case "5UiU3b4CaGE":
        Script32();
        break;
      case "6cCANpMquT4":
        Script33();
        break;
      case "5Zt9Ame83lN":
        Script34();
        break;
      case "6grYuDFecNE":
        Script35();
        break;
      case "5xYtZ5BGYg3":
        Script36();
        break;
      case "5vxEtiziiSY":
        Script37();
        break;
      case "69V2H0exuqV":
        Script38();
        break;
      case "5qKONpvj63T":
        Script39();
        break;
      case "6FOONIWDu6Y":
        Script40();
        break;
      case "5xEb5bs9Rah":
        Script41();
        break;
      case "6EmMTP10ZkQ":
        Script42();
        break;
      case "68Vwirm1rLS":
        Script43();
        break;
      case "6JlwgWsEyG8":
        Script44();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
};
